from flask import Flask, send_from_directory  # Flask 관련 클래스와 메서드
from flask_sqlalchemy import SQLAlchemy       # 데이터베이스 ORM
from flask_migrate import Migrate             # 데이터베이스 마이그레이션
import os                                     # 경로 처리를 위한 OS 모듈

# 데이터베이스와 마이그레이션 초기화
db = SQLAlchemy()
migrate = Migrate()

def create_app():
    """Flask 앱을 생성하고 설정 및 블루프린트를 등록합니다."""
    app = Flask(__name__)
    app.config.from_object('app.config.Config')  # 설정 파일 로드

    # 데이터베이스와 마이그레이션 초기화
    db.init_app(app)
    migrate.init_app(app, db)

    # 블루프린트 등록
    from app.routes.auth_routes import auth_bp
    from app.routes.course_routes import course_bp
    from app.routes.review_routes import review_bp
    from app.routes.stats_routes import stats_bp

    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(course_bp, url_prefix='/courses')
    app.register_blueprint(review_bp, url_prefix='/reviews')
    app.register_blueprint(stats_bp, url_prefix='/stats')

    # 루트 경로 정의
    @app.route('/')
    def home():
        return "<h1>Welcome to the Flask API</h1><p>This is the home page.</p>"

    # favicon 경로 처리
    @app.route('/favicon.ico')
    def favicon():
        return send_from_directory(
            os.path.join(app.root_path, 'static'),
            'favicon.ico',
            mimetype='image/vnd.microsoft.icon'
        )

    return app

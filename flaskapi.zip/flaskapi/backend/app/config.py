class Config:
    SQLALCHEMY_DATABASE_URI = 'sqlite:///app.db'  # SQLite 데이터베이스 URI
    SQLALCHEMY_TRACK_MODIFICATIONS = False       # 비추적 모드 설정
    SECRET_KEY = 'supersecretkey'                # 플라스크 비밀 키

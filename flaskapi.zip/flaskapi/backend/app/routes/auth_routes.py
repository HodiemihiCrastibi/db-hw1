from flask import Blueprint, jsonify, request  # Flask 관련 모듈

auth_bp = Blueprint('auth', __name__)  # 블루프린트 생성

# 회원가입 엔드포인트
@auth_bp.route('/signup', methods=['POST'])
def signup():
    try:
        # 요청 데이터 확인
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # 필수 필드 검증
        required_fields = ['name', 'email', 'password']
        missing_fields = [field for field in required_fields if field not in data]
        if missing_fields:
            return jsonify({'error': f"Missing fields: {', '.join(missing_fields)}"}), 400
        
        # 이메일 형식 검증 (간단한 예)
        if '@' not in data['email']:
            return jsonify({'error': 'Invalid email format'}), 400
        
        # 성공적으로 등록된 사용자 응답
        return jsonify({'message': f"User {data['name']} registered successfully"}), 201
    
    except Exception as e:
        # 서버 오류 처리
        return jsonify({'error': 'An error occurred', 'details': str(e)}), 500

from flask import Blueprint, send_from_directory
import os

misc_bp = Blueprint('misc', __name__)

@misc_bp.route('/favicon.ico')
def favicon():
    return send_from_directory(
        os.path.join(os.path.dirname(__file__), '../static'),
        'favicon.ico',
        mimetype='image/vnd.microsoft.icon'
    )

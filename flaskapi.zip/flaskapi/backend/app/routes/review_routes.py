from flask import Blueprint, jsonify

review_bp = Blueprint('reviews', __name__)  # 'reviews'는 고유한 블루프린트 이름

@review_bp.route('/', methods=['GET'])
def get_reviews():
    return jsonify({'message': 'Reviews endpoint works!'})

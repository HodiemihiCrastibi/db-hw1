from flask import Blueprint, jsonify, request

course_bp = Blueprint('courses', __name__)  # 블루프린트 생성

# 샘플 데이터: 수업 목록
COURSES = [
    {"id": 1, "title": "Python for Beginners", "category": "Programming", "difficulty": "Beginner"},
    {"id": 2, "title": "Advanced Flask", "category": "Programming", "difficulty": "Advanced"},
    {"id": 3, "title": "Machine Learning Basics", "category": "Data Science", "difficulty": "Intermediate"},
    {"id": 4, "title": "React for Beginners", "category": "Web Development", "difficulty": "Beginner"}
]

@course_bp.route('/', methods=['GET'])
def get_courses():
    """
    수업 목록을 가져오거나 필터링합니다.
    쿼리 파라미터:
      - category: 특정 카테고리로 필터링 (예: Programming)
      - difficulty: 난이도로 필터링 (예: Beginner)
    """
    try:
        # 쿼리 파라미터 가져오기
        category = request.args.get('category')  # 카테고리 필터
        difficulty = request.args.get('difficulty')  # 난이도 필터

        # 기본 데이터: 모든 수업
        filtered_courses = COURSES

        # 카테고리 필터 적용
        if category:
            filtered_courses = [course for course in filtered_courses if course['category'].lower() == category.lower()]

        # 난이도 필터 적용
        if difficulty:
            filtered_courses = [course for course in filtered_courses if course['difficulty'].lower() == difficulty.lower()]

        # 결과 반환
        return jsonify(filtered_courses), 200

    except Exception as e:
        return jsonify({'error': 'An error occurred', 'details': str(e)}), 500

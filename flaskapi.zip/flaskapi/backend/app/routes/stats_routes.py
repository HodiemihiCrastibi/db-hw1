from flask import Blueprint, jsonify

stats_bp = Blueprint('stats', __name__)  # 'stats'는 고유한 블루프린트 이름

@stats_bp.route('/average', methods=['GET'])
def get_average():
    return jsonify({'message': 'Stats endpoint works!'})

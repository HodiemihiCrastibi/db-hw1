from app import create_app  # create_app 함수 가져오기

app = create_app()

if __name__ == '__main__':
    app.run(debug=True)  # 디버그 모드 활성화
CORS(app)
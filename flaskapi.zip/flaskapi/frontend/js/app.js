// Backend API URL (update as needed)
const API_URL = "http://127.0.0.1:5000";


// Page elements
const mainContent = document.getElementById("main-content");

// Utility function to fetch and display content
async function fetchContent(endpoint) {
    try {
        const response = await fetch(`${API_URL}${endpoint}`);
        if (!response.ok) throw new Error(`Error: ${response.status}`);
        const data = await response.json();
        renderContent(data);
    } catch (error) {
        mainContent.innerHTML = `<p>${error.message}</p>`;
    }
}

// Render content dynamically
function renderContent(data) {
    mainContent.innerHTML = `<pre>${JSON.stringify(data, null, 2)}</pre>`;
}

// Event listeners for navigation
document.getElementById("home-link").addEventListener("click", () => {
    mainContent.innerHTML = `<p>Welcome to the Flask API Frontend!</p>`;
});

document.getElementById("auth-link").addEventListener("click", () => {
    fetchContent("/auth/users");
});

document.getElementById("courses-link").addEventListener("click", () => {
    fetchContent("/courses");
});

document.getElementById("reviews-link").addEventListener("click", () => {
    fetchContent("/reviews");
});

document.getElementById("stats-link").addEventListener("click", () => {
    fetchContent("/stats");
});
